package com.example.recetario_beta

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
